package org.upmobile.materialmusicdownloader;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class Nulldroid_MusicPlayerReceiver extends BroadcastReceiver  {


		@Override
		public void onReceive(final Context paramContext, Intent intent) {

		}
		
}
