package org.upmobile.materialmusicdownloader.models;

public interface BaseMaterialFragment {
	
	public int getDrawerIcon();
	public int getDrawerTitle();
	public int getDrawerTag();
}
